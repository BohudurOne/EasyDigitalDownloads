<?php
!defined('BOHUDUR') && exit("what's you are trying to do?");

class Bohudur {
    private static $baseUrl = 'https://request.bohudur.one/';
    
    private $apiKey;
    
    public function __construct($apiKey) {
        if(ctype_alnum($apiKey)) {
            $this->apiKey = $apiKey;
        } else {
            $this->returnResponse(2001, "Invalid API key");
        }
    }
    
    public function sendRequest($requestData) {
        if(!$this->validateRequestData($requestData)) {
            $this->returnResponse(2002, "Required Parameters Not Found!");
        }
        
        $headers = [
            'Content-Type: application/json',
            'AH-BOHUDUR-API-KEY: ' . $this->apiKey
        ];
        
        $data = json_encode($requestData);
        
        $requestUrl = self::$baseUrl . 'create/';
    
        $ch = curl_init($requestUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $this->returnResponse(2003, curl_error($ch));
        }
        
        curl_close($ch);
        return json_decode($response, true);
    }
    
    public function executePayment($paymentKey) {
        $requestData = json_encode([
            'paymentkey' => $paymentKey
        ]);
        
        $headers = [
            'Content-Type: application/json',
            'AH-BOHUDUR-API-KEY: ' . $this->apiKey
        ];
        
        $executeUrl = self::$baseUrl . 'execute/';
        
        $ch = curl_init($executeUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $this->returnResponse(2004, curl_error($ch));
        }
        
        curl_close($ch);
        return json_decode($response, true);
    }
    
    public function verifyPayment($paymentKey) {
        $requestData = json_encode([
            'paymentkey' => $paymentKey
        ]);
        
        $headers = [
            'Content-Type: application/json',
            'AH-BOHUDUR-API-KEY: ' . $this->apiKey
        ];
        
        $verifyUrl = self::$baseUrl . 'verify/';
        
        $ch = curl_init($verifyUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $this->returnResponse(2004, curl_error($ch));
        }
        
        curl_close($ch);
        return json_decode($response, true);
    }
    
    private function validateRequestData($requestData) {
        if (!isset($requestData['fullname'], $requestData['amount'], $requestData['redirect_url'], $requestData['cancelled_url'], $requestData['return_type'], $requestData['email'])) {
            return false;
        }
        
        return true;
    }
    
    private function returnResponse($code, $message) {
        return json_encode(['responseCode' => $code, 'message' => $message, 'status' => "failed"]);
    }
}