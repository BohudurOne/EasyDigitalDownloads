<?php
/**
 * Plugin Name: Bohudur EDD
 * Plugin URI: https://bohudur.one
 * Description: Add Bohudur as a payment gateway for Easy Digital Downloads.
 * Version: 1.0.0
 * Author: Bohudur
 * Author URI: https://bohudur.one
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: edd-bohudur
 */

// Prevent direct access to the file
defined('ABSPATH') || exit;

// Autoload classes
define('BOHUDUR', true);
require_once plugin_dir_path(__FILE__) . 'lib/BohudurEdd.php';

function edd_bohudur_check_version()
{
    if (!defined('EDD_VERSION') || version_compare(EDD_VERSION, '3.0.0', '<')) {
        add_action('admin_notices', function () {
            echo '<div class="error"><p>' . __('Bohudur EDD Gateway requires Easy Digital Downloads version 3.0.0 or higher.', 'edd-bohudur') . '</p></div>';
        });
    }
}
add_action('plugins_loaded', 'edd_bohudur_check_version');

/**
 * Registers Bohudur as a payment gateway in Easy Digital Downloads.
 *
 * @param array $gateways Existing gateways.
 * @return array Modified gateways.
 */
function edd_bohudur_register_gateway($gateways)
{
    $display_name = edd_get_option('edd_bohudur_display_name', __('Bohudur', 'edd-bohudur'));

    $gateways['bohudur'] = [
        'admin_label'    => 'Bohudur',
        'checkout_label' => $display_name,
        'supports'       => ['buy_now'],
    ];

    return $gateways;
}
add_filter('edd_payment_gateways', 'edd_bohudur_register_gateway');

/**
 * Adds Bohudur settings section in Easy Digital Downloads.
 *
 * @param array $sections Existing sections.
 * @return array Modified sections.
 */
function edd_bohudur_add_settings_section($sections)
{
    $sections['bohudur'] = __('Bohudur', 'edd-bohudur');
    return $sections;
}
add_filter('edd_settings_sections_gateways', 'edd_bohudur_add_settings_section');

/**
 * Adds Bohudur settings fields in Easy Digital Downloads.
 *
 * @param array $settings Existing settings.
 * @return array Modified settings.
 */
function edd_bohudur_add_settings($settings)
{
    $bohudur_settings = [
        'bohudur' => [
            [
                'id'      => 'edd_bohudur_settings',
                'name'    => '<strong>' . __('Bohudur Settings', 'edd-bohudur') . '</strong>',
                'desc'    => __('Configure the Bohudur settings.', 'edd-bohudur'),
                'type'    => 'header',
            ],
            [
                'id'      => 'edd_bohudur_display_name',
                'name'    => __('Gateway Display Name', 'edd-bohudur'),
                'desc'    => __('Enter the name that will be displayed on the checkout page for the Bohudur gateway.', 'edd-bohudur'),
                'type'    => 'text',
                'size'    => 'regular',
            ],
            [
                'id'      => 'edd_bohudur_api_key',
                'name'    => __('API KEY', 'edd-bohudur'),
                'desc'    => __('Enter your Bohudur API KEY.', 'edd-bohudur'),
                'type'    => 'text',
            ],
            [
                'id'      => 'edd_bohudur_webhook_success',
                'name'    => __('Webhook Success URL', 'edd-bohudur'),
                'desc'    => __('You can keep it blank. Because it is not required for payment.', 'edd-bohudur'),
                'type'    => 'text',
            ],
            [
                'id'      => 'edd_bohudur_webhook_cancel',
                'name'    => __('Webhook Cancelled URL', 'edd-bohudur'),
                'desc'    => __('You can keep it blank. Because it is not required for payment.', 'edd-bohudur'),
                'type'    => 'text',
            ],
            [
                'id'      => 'edd_bohudur_currency_rate',
                'name'    => __('Currency Rate', 'edd-bohudur'),
                'desc'    => __('You can use Bohudur Inbuilt Currency Converter by keeping it blank. But if you want to give custom rate of any currency then you can give. Like 1 USD = 120 BDT, you need to give 120.', 'edd-bohudur'),
                'type'    => 'number',
                'default' => 1,
            ],
        ],
    ];

    return array_merge($settings, $bohudur_settings);
}
add_filter('edd_settings_gateways', 'edd_bohudur_add_settings');

/**
 * Processes Bohudur payment.
 *
 * @param array $purchase_data Purchase data.
 */
function edd_bohudur_process_payment($purchase_data)
{
    if (edd_get_errors()) {
        edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
    }
    
    if(edd_get_option('edd_bohudur_api_key') == ''){
        edd_set_error('bohudur_error', __('API key not found!', 'edd-bohudur'));
        edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
    }

    $payment_data = [
        'price'        => $purchase_data['price'],
        'date'         => $purchase_data['date'],
        'user_email'   => $purchase_data['user_email'],
        'purchase_key' => $purchase_data['purchase_key'],
        'downloads'    => $purchase_data['downloads'],
        'cart_details' => $purchase_data['cart_details'],
        'user_info'    => $purchase_data['user_info'],
        'status'       => 'pending',
    ];

    $payment_id = edd_insert_payment($payment_data);
    
    if (!$payment_id) {
        edd_set_error('bohudur_error', __('You must enter your Bohudur credentials in settings.', 'edd-bohudur'));
        edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
    }

    $amount = (float) $purchase_data['price'];
    $currency = edd_get_currency();
    $currency_rate = 1;
    
    if($currency != 'BDT'){
        if(edd_get_option('edd_bohudur_currency_rate') != 0 || edd_get_option('edd_bohudur_currency_rate') != ''){
            $currency_rate = edd_get_option('edd_bohudur_currency_rate');
        }else{
            $currency_rate = 0;
        }
    }

    $requestData = [
        'fullname'       => sanitize_text_field($purchase_data['user_info']['first_name']),
        'email'          => sanitize_email($purchase_data['user_info']['email']),
        'amount'         => $amount,
        'return_type'    => 'Q',
        'currency'       => $currency,
        'currency_value' => $currency_rate,
        'redirect_url'   => add_query_arg('payment-confirmation', 'bohudur_success', edd_get_success_page_uri()),
        'cancelled_url'  => add_query_arg('payment-confirmation', 'bohudur_cancel', edd_get_success_page_uri()),
        'metadata'       => ['payment_id' => $payment_id],
    ];
    
    
    if(edd_get_option('edd_bohudur_webhook_success') != '' && edd_get_option('edd_bohudur_webhook_cancel') != ''){
        $data['webhook'] = [
            'success' => edd_get_option('edd_bohudur_webhook_success'),
            'cancel'  => edd_get_option('edd_bohudur_webhook_cancel')
        ];
    }else if(!empty(edd_get_option('edd_bohudur_webhook_success'))){
        $data['webhook'] = [
            'success' => edd_get_option('edd_bohudur_webhook_success'),
        ];
    }else if(!empty(edd_get_option('edd_bohudur_webhook_cancel'))){
        $data['webhook'] = [
            'cancel' => edd_get_option('edd_bohudur_webhook_cancel'),
        ];
    }

    try {
        $bohudur = new Bohudur(edd_get_option('edd_bohudur_api_key'));
        $result = $bohudur->sendRequest($requestData);
    
        if (isset($result['responseCode']) && $result['responseCode'] == 200) {
            if (isset($result['payment_url'])) {
                wp_redirect($result['payment_url']);
                exit;
            } else {
                edd_set_error('bohudur_error', __('Payment URL not received from Bohudur.', 'edd-bohudur'));
                edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
            }
        } else {
            edd_set_error('bohudur_error', __('Bohudur payment failed: ', 'edd-bohudur') . json_encode($result));
            edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
        }
    } catch (Exception $e) {
        edd_set_error('bohudur_error', __('Initialization Error: ', 'edd-bohudur') . esc_html($e->getMessage()));
        edd_send_back_to_checkout('?payment-mode=' . sanitize_text_field($purchase_data['post_data']['edd-gateway']));
    }
}

add_action('edd_gateway_bohudur', 'edd_bohudur_process_payment');

/**
 * Handles payment confirmation for Bohudur.
 */
function edd_bohudur_payment_confirmation()
{
    if (empty($_GET['payment-confirmation'])) return;
    $confirmation_type = sanitize_text_field($_GET['payment-confirmation']);
    
    if ($confirmation_type === 'bohudur_cancel') {
        edd_set_error('bohudur_error', __('Payment cancelled by user.', 'edd-bohudur'));
        edd_send_back_to_checkout();
        exit;
    }
    
    if ($confirmation_type === 'bohudur_success' && isset($_GET['payment_key'])) {
        try {
            $bohudur = new Bohudur(edd_get_option('edd_bohudur_api_key'));

            $response = $bohudur->executePayment(sanitize_text_field($_GET['payment_key']));
            if (isset($response['Status']) && $response['Status'] == 'EXECUTED') {
                $metadata = json_decode($response['Metadata'], true);
                if (isset($metadata['payment_id'])) {
                    $payment_id = intval($metadata['payment_id']);
                    $payment = edd_get_payment($payment_id);

                    if ($payment && $payment->status === 'pending') {
                        edd_update_payment_status($payment_id, 'complete');
                        edd_insert_payment_note($payment_id, __('Payment completed successfully through Bohudur.', 'edd-bohudur'));
                    }
                    edd_send_to_success_page();
                    exit;
                } else {
                    edd_set_error('bohudur_error', __('Invalid metadata in response from Bohudur.', 'edd-bohudur'));
                }
            } else {
                edd_set_error('bohudur_error', __('Payment verification failed.', 'edd-bohudur'));
            }
        } catch (Exception $e) {
            edd_set_error('bohudur_error', __('Initialization Error: ', 'edd-bohudur') . esc_html($e->getMessage()));
        }

        edd_send_back_to_checkout();
        exit;
    }
}
add_action('template_redirect', 'edd_bohudur_payment_confirmation');

/**
 * Disables the credit card form for the Bohudur gateway.
 *
 * @return bool False if Bohudur is the selected gateway, otherwise the original value.
 */
function edd_bohudur_cc_form()
{
    if (edd_get_chosen_gateway() === 'bohudur') {
        return false;
    }
}
add_action('edd_bohudur_cc_form', 'edd_bohudur_cc_form');