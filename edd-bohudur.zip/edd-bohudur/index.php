<?php
exit("what do you want to do?");
?>